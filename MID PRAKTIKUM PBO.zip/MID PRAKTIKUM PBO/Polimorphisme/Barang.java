class Barang{
	private String nama;

	
	public Barang(String nama){
		this.nama = nama;
	}
	
	public String getNama(){
		return nama;
	}

	
	protected void input(){
		
	}
	protected void pilihan(){
		
	}
	protected void pembayaran(){
		
	}
	protected void cetak(){
		
	}
	
}