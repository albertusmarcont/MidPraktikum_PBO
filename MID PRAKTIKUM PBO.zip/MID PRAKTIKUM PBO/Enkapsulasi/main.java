import java.util.Scanner;

public class main{
	void sub (String nama, int total,int bayar,int kembalian){
	
		   
	   
		
	   System.out.println("Nama        : "+nama );
	   System.out.println("Total Harga : Rp."+total);
	   System.out.println("Bayar       : Rp."+bayar);
	   System.out.println("-------------------------------------------");
	   System.out.println("Kembalian   : Rp."+kembalian);
	   }
}