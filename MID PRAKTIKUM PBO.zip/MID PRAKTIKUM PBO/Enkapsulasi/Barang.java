
public class Barang extends main{
	private int total;	
	
	void datajumlah(int jumlah, int bayar, int kembalian, int harga){
	
	
       System.out.println("Total Harga = Rp "+total);
      
		}
		}